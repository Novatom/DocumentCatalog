﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentCatalog
{
    /// <summary>
    /// Класс папки каталога документов
    /// </summary>
    public class Folder
    {
        /// <summary>
        /// Счетчик следующего отрицательного идентификатора папки
        /// </summary>
        private static int nextNewId;

        /// <summary>
        /// Указывает, что папка выбрана пользователем
        /// </summary>
        public bool IsSelected { get; set; }

        /// <summary>
        /// Указывает, что папка раскрыта
        /// </summary>
        public bool IsExpanded { get; set; }

        /// <summary>
        /// Идентификатор папки
        /// </summary>
        public int Id { get; internal set; }

        /// <summary>
        /// Идентификатор родителя (надпапки)
        /// </summary>
        public int ParentId { get; internal set; }

        /// <summary>
        /// Наименование папки
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Каталог папки
        /// </summary>
        internal DocumentCatalog catalog;

        private List<Folder> folders;
        /// <summary>
        /// Коллекция подпапок (детей)
        /// </summary>
        public IList<Folder> Folders
        {
            get { return folders; }
        }

        /// <summary>
        /// Коллекция документов текущей папки
        /// </summary>
        public IEnumerable<Document> Documents
        {
            get { return catalog != null ? catalog.Documents.Where(d => d.ParentId == this.Id) : Enumerable.Empty<Document>(); }
        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        private Folder()
        {
            Id = --nextNewId;
            Name = string.Empty;
            folders = new List<Folder>();
        }

        /// <summary>
        /// Конструктор папки по имени
        /// </summary>
        public Folder(string name)
            : this()
        {
            Name = name;
        }

        /// <summary>
        /// Добавление подпапки
        /// </summary>
        /// <param name="folder">Добавляемая подпапка</param>
        public void AddFolder(Folder folder)
        {
            if (folder == null)
            {
                throw new ArgumentNullException("folder");
            }

            if (folder == this)
            {
                throw new Exception("The same folder");
            }

            if (IsDuplicateFolderName(folder.Name))
            {
                // TODO - как-то уведомить пользователя о том, что такое имя на этом уровне уже существует
                return;
            }

            folder.catalog = this.catalog;
            folder.ParentId = this.Id;

            Folders.Add(folder);
        }

        /// <summary>
        /// Проверка дубликата имени папки
        /// </summary>
        /// <param name="name">Проверяемое имя</param>
        /// <returns></returns>
        private bool IsDuplicateFolderName(string name)
        {
            return folders.Any(f => f.Name.Equals(name));
        }

        /// <summary>
        /// Добавление документа
        /// </summary>
        /// <param name="document"></param>
        public void AddDocument(Document document)
        {
            if (document == null)
            {
                throw new ArgumentNullException("name");
            }

            if (catalog.IsDuplicateDocumentName(document.Name))
            {
                // TODO - как-то уведомить пользователя о том, что такое имя документа в каталоге уже существует
                return;
            }

            document.ParentId = this.Id;
            catalog.Documents.Add(document);
        }

        /// <summary>
        /// Удаление папки
        /// </summary>
        /// <param name="folder">Удаляемая папка</param>
        /// <returns></returns>
        public bool RemoveFolder(Folder folder)
        {
            if (folder == null)
            {
                throw new ArgumentNullException("folder");
            }

            var result = folders.Remove(folder);
            if (result)
            {
                folder.catalog = null;
                folder.ParentId = -1;
            }

            return result;
        }

        /// <summary>
        /// Удаление документа
        /// </summary>
        /// <param name="document">Удаляемый документ</param>
        /// <returns></returns>
        public bool RemoveDocument(Document document)
        {
            if (document == null)
            {
                throw new ArgumentNullException("document");
            }

            var result = catalog.Documents.Remove(document);
            if (result)
            {
                document.ParentId = -1;
            }

            return result;
        }

        /// <summary>
        /// Получение папки по её идентификатору
        /// </summary>
        /// <param name="id">Искомый идентифактор</param>
        /// <returns></returns>
        internal Folder GetFolderById(int id)
        {
            Folder result = Folders.SingleOrDefault(f => f.Id == id);

            if (result == null)
            {
                foreach (var folder in Folders)
                {
                    result = folder.GetFolderById(id);

                    if (result != null)
                    {
                        break;
                    }
                }
            }

            return result;  
        }
    }
}
