﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentCatalog
{
    /// <summary>
    /// Класс каталога документов
    /// </summary>
    public class DocumentCatalog
    {
        private List<Folder> folders;
        /// <summary>
        /// Коллекция папок каталога документов
        /// </summary>
        public IList<Folder> Folders
        {
            get { return folders; }
        }

        private List<Document> documents;
        /// <summary>
        /// Коллекция документов каталога
        /// </summary>
        public IList<Document> Documents
        {
            get { return documents; }
        }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        public DocumentCatalog()
        {
            folders = new List<Folder>();
            documents = new List<Document>();
        }

        /// <summary>
        /// Добавление папки в каталог
        /// </summary>
        /// <param name="folder">Добавляемая папка</param>
        public void AddFolder(Folder folder)
        {
            if (folder == null)
            {
                throw new ArgumentNullException("folder");
            }

            if (IsDuplicateFolderName(folder.Name))
            {
                // TODO - как-то уведомить пользователя о том, что такое имя на этом уровне уже существует
                return;
            }

            folder.catalog = this;
            Folders.Add(folder);
        }

        /// <summary>
        /// Проверка дубликата имени папки
        /// </summary>
        /// <param name="name">Проверяемое имя</param>
        /// <returns></returns>
        private bool IsDuplicateFolderName(string name)
        {
            return folders.Any(f => f.Name.Equals(name));
        }

        /// <summary>
        /// Проверка дубликата имени документа по всему каталогу
        /// </summary>
        /// <param name="name">Проверяемое имя</param>
        /// <returns></returns>
        internal bool IsDuplicateDocumentName(string name)
        {
            return documents.Any(d => d.Name.Equals(name));
        }

        /// <summary>
        /// Удаление папки
        /// </summary>
        /// <param name="folder">Удаляемая папка</param>
        /// <returns></returns>
        public bool RemoveFolder(Folder folder)
        {
            if (folder != null)
            {
                throw new ArgumentNullException("folder");
            }

            folder.ParentId = -1;
            folder.catalog = null;

            var result = folders.Remove(folder);

            if (result)
            {
                folder.ParentId = -1;
                folder.catalog = null;
            }

            return result;
        }

        /// <summary>
        /// Получение документов по имени
        /// </summary>
        /// <param name="name">Искомое имя</param>
        /// <param name="option">Опции поиска</param>
        /// <returns>Коллекция найденных папок</returns>
        public IEnumerable<Document> GetDocumentsByName(string name, CatalogSearchOption option)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            var documents = Enumerable.Empty<Document>();

            switch (option)
            {
                case CatalogSearchOption.Equals:
                    documents = Documents.Where(d => d.Name.Equals(name));
                    break;

                case CatalogSearchOption.Contains:
                    documents = Documents.Where(d => d.Name.Contains(name));
                    break;

                case CatalogSearchOption.StartsWith:
                    documents = Documents.Where(d => d.Name.StartsWith(name));
                    break;

                case CatalogSearchOption.EndsWith:
                    documents = Documents.Where(d => d.Name.EndsWith(name));
                    break;

                default:
                    break;
            }

            return documents.ToArray();
        }

        /// <summary>
        /// Получение папки по её идентификатору
        /// </summary>
        /// <param name="id">Искомый идентификатор</param>
        /// <returns>Найденую папку, null если папка не найдена</returns>
        public Folder GetFolderById(int id)
        {
            Folder result = Folders.SingleOrDefault(f => f.Id == id);

            if (result == null)
            {
                foreach (var folder in Folders)
                {
                    result = folder.GetFolderById(id);

                    if (result != null)
                    {
                        break;
                    }
                }
            }

            return result;
        }
    }

    /// <summary>
    /// Перечисление опций поиска элементов в каталоге
    /// </summary>
    public enum CatalogSearchOption
    {
        /// <summary>
        /// Элемент соответствует
        /// </summary>
        Equals,
        /// <summary>
        /// Элемент содержит
        /// </summary>
        Contains,
        /// <summary>
        /// Элемент начинается с
        /// </summary>
        StartsWith,
        /// <summary>
        /// Элемент заканчивается на
        /// </summary>
        EndsWith
    }
}
