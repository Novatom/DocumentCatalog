﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentCatalog
{
    public class Document
    {
        /// <summary>
        /// Счетчик следующего отрицательного идентификатора документа
        /// </summary>
        private static int nextNewId;

        /// <summary>
        /// Идентификатор документа
        /// </summary>
        public int Id { get; internal set; }

        /// <summary>
        /// Идентификатор родителя (папки)
        /// </summary>
        public int ParentId { get; internal set; }

        /// <summary>
        /// Наименование документа
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Дата сохранения документа
        /// </summary>
        public DateTime SavingDate { get; set; }

        /// <summary>
        /// Пользователь сохранивший документ
        /// </summary>
        public string User { get; set; }

        /// <summary>
        /// Пользователь сохранивший веса в документе
        /// </summary>
        public string UserSaveWeight { get; set; }

        /// <summary>
        /// Дата сохранения весов в документе
        /// </summary>
        public DateTime WeightSavingDate { get; set; }

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        private Document()
        {
            Id = --nextNewId;
            Name = string.Empty;
            User = string.Empty;
            UserSaveWeight = string.Empty;
        }

        /// <summary>
        /// Конструктор документа по имени
        /// </summary>
        /// <param name="name"></param>
        public Document(string name)
            : this()
        {
            Name = name;
        }
    }
}
