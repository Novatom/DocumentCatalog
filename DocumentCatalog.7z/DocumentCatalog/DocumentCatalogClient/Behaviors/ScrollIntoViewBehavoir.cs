﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Interactivity;

namespace DocumentCatalogClient.Behaviors
{
    public class ScrollIntoViewBehavoir : Behavior<DataGrid>
    {
        protected override void OnAttached()
        {
            base.OnAttached();
            this.AssociatedObject.SelectionChanged += new SelectionChangedEventHandler(AssociatedObject_SelectionChanged);
        }

        void AssociatedObject_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var grid = sender as DataGrid;
            if (grid != null && grid.SelectedItem != null)
            {
                Action<DataGrid> action = delegate(DataGrid dataGrid)
                {
                    dataGrid.ScrollIntoView(dataGrid.SelectedItem);
                    dataGrid.Focus();
                };

                grid.Dispatcher.BeginInvoke(action, grid);
            }
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            this.AssociatedObject.SelectionChanged -= new SelectionChangedEventHandler(AssociatedObject_SelectionChanged);
        }
    }
}
