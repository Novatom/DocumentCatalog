﻿using GalaSoft.MvvmLight;
using DocumentCatalogClient.Model;
using DocumentCatalog;
using System.Collections.ObjectModel;
using System;
using GalaSoft.MvvmLight.CommandWpf;
using System.Linq;
using System.Windows.Controls;

namespace DocumentCatalogClient.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// See http://www.mvvmlight.net
    /// </para>
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        private readonly IDataService _dataService;

        /// <summary>
        /// Каталог документов
        /// </summary>
        private readonly DocumentCatalog.DocumentCatalog documentCatalog;

        public ObservableCollection<Folder> folders;
        /// <summary>
        /// Коллекция папок
        /// </summary>
        public ObservableCollection<Folder> Folders
        {
            get { return folders; }
            set
            {
                Set(ref folders, value);
            }
        }

        private Folder selectedFolder;
        /// <summary>
        /// Выбранная папка
        /// </summary>
        public Folder SelectedFolder
        {
            get { return selectedFolder; }
            set
            {
                if (Set(ref selectedFolder, value))
                {
                    Documents = new ObservableCollection<Document>(selectedFolder.Documents);
                }
            }
        }

        private ObservableCollection<Document> documents;
        /// <summary>
        /// Коллекция документов
        /// </summary>
        public ObservableCollection<Document> Documents
        {
            get { return documents; }
            set
            {
                Set(ref documents, value);
            }
        }

        private Document selectedDocument;
        /// <summary>
        /// Выбранный документ
        /// </summary>
        public Document SelectedDocument
        {
            get { return selectedDocument; }
            set
            {
                Set(ref selectedDocument, value);
            }
        }

        /// <summary>
        /// Коллекция найденных документов
        /// </summary>
        public ObservableCollection<Document> FoundDocuments { get; set; }

        private string searchDocumentName;
        /// <summary>
        /// Имя искомого документа
        /// </summary>
        public string SearchDocumentName
        {
            get { return searchDocumentName; }
            set
            {
                if (FoundDocuments.Any(d => d.Name.Equals(value)) == false)
                {
                    if (Set(ref searchDocumentName, value))
                    {
                        FoundDocuments.Clear();

                        if (string.IsNullOrWhiteSpace(searchDocumentName) == false)
                        {
                            foreach (var foundDocument in documentCatalog.Documents.Where(d => d.Name.StartsWith(searchDocumentName)))
                            {
                                FoundDocuments.Add(foundDocument);
                            }
                        }
                    }
                }
                else
                {
                    Set(ref searchDocumentName, value);
                }
            }
        }

        /// <summary>
        /// Команда открытия документа
        /// </summary>
        public RelayCommand OpenDocumentCommand { get; private set; }

        public RelayCommand<TreeViewItem> TreeViewItem_SelectedCommand { get; private set; }

        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel(IDataService dataService)
        {
            _dataService = dataService;

            documentCatalog = new DocumentCatalog.DocumentCatalog();

            var rootFolder = new Folder("Root");

            SelectedFolder = rootFolder;

            documentCatalog.AddFolder(rootFolder);
            var testFolder = new Folder("Test 1");
            
            rootFolder.AddFolder(testFolder);

            rootFolder.AddFolder(new Folder("Test 2"));

            var rootFolderDocument = new Document("Test document") { SavingDate = DateTime.Now };
            rootFolder.AddDocument(rootFolderDocument);

            var moreDocument = new Document("More document");
            testFolder.AddDocument(moreDocument);
            foreach (var item in Enumerable.Range(0, 2500))
            {
                var newDoc = new Document(item + " Doc") { SavingDate = DateTime.Now };

                testFolder.AddDocument(newDoc);
            }
            
            //var res1 = documentCatalog.GetDocumentsByName("Test", CatalogSearchOption.Contains);

            //var res2 = documentCatalog.GetFolderById(-31);



            Folders = new ObservableCollection<Folder>(documentCatalog.Folders);
            Documents = new ObservableCollection<Document>(documentCatalog.Documents);
            FoundDocuments = new ObservableCollection<Document>();

            OpenDocumentCommand = new RelayCommand(OpenDocument, CanOpenDocument);
            TreeViewItem_SelectedCommand = new RelayCommand<TreeViewItem>(TreeViewItem_Selected);

            rootFolder.IsExpanded = true;
            testFolder.IsSelected = true;
        }

        private void TreeViewItem_Selected(TreeViewItem treeViewItem)
        {
            throw new NotImplementedException();
        }

        private bool CanOpenDocument()
        {
            return selectedDocument != null;
        }

        private void OpenDocument()
        {
            //host.OpenDocument(selectedDocument);
        }

        ////public override void Cleanup()
        ////{
        ////    // Clean up if needed

        ////    base.Cleanup();
        ////}
    }

    internal class ttt : GalaSoft.MvvmLight.Views.IDialogService, GalaSoft.MvvmLight.Views.INavigationService
    {
        #region INavigationService memebers
        public string CurrentPageKey
        {
            get { throw new NotImplementedException(); }
        }

        public void GoBack()
        {
            throw new NotImplementedException();
        }

        public void NavigateTo(string pageKey, object parameter)
        {
            throw new NotImplementedException();
        }

        public void NavigateTo(string pageKey)
        {
            throw new NotImplementedException();
        }
        #endregion INavigationService memebers

        #region IDialogService memebers
        public System.Threading.Tasks.Task ShowError(Exception error, string title, string buttonText, Action afterHideCallback)
        {
            throw new NotImplementedException();
        }

        public System.Threading.Tasks.Task ShowError(string message, string title, string buttonText, Action afterHideCallback)
        {
            throw new NotImplementedException();
        }

        public System.Threading.Tasks.Task<bool> ShowMessage(string message, string title, string buttonConfirmText, string buttonCancelText, Action<bool> afterHideCallback)
        {
            throw new NotImplementedException();
        }

        public System.Threading.Tasks.Task ShowMessage(string message, string title, string buttonText, Action afterHideCallback)
        {
            throw new NotImplementedException();
        }

        public System.Threading.Tasks.Task ShowMessage(string message, string title)
        {
            throw new NotImplementedException();
        }

        public System.Threading.Tasks.Task ShowMessageBox(string message, string title)
        {
            throw new NotImplementedException();
        }
        #endregion IDialogService memebers
    }
}